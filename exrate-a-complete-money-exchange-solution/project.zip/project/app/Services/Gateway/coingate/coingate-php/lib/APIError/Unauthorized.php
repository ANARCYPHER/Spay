<?php

namespace CoinGate\APIError;

# HTTP Status 401
class Unauthorized extends APIError
{
}

<?php

namespace CoinGate\APIError;

# HTTP Status 429
class RateLimitException extends APIError
{
}


<?php return array (
  'meta_image' => 'meta.png',
  'meta_keywords' => 'Currency Exchange,  Dollar Exchange,  exchanger, dollar buy sell, cryptocurrency buy sell, money exchange, crypto,  currency convert, cryptocurrency, currency, buy sell,buy, sell, exchange',
  'meta_description' => 'EX-RATE -  Money Exchange Solution',
  'social_title' => 'EX-RATE -   Money Exchange Solution',
  'social_description' => 'EX-RATE -   Money Exchange Solution',
);
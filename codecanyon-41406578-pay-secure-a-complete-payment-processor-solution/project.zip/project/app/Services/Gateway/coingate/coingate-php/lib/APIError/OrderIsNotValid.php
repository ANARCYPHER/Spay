<?php

namespace CoinGate\APIError;

# HTTP Status 422
class OrderIsNotValid extends UnprocessableEntity
{
}

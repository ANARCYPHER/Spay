<?php

namespace StripeJS\Error;

class Authentication extends Base
{
}

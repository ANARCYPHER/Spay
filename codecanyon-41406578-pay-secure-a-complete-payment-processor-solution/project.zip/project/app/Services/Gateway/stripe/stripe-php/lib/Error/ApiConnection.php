<?php

namespace StripeJS\Error;

class ApiConnection extends Base
{
}
